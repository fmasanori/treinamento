from urllib.request import urlopen
from bs4 import BeautifulSoup

url = 'https://www.dicionariodenomesproprios.com.br/top-brasil/'
html = urlopen(url)
bsObj = BeautifulSoup(html.read(), 'html.parser')
lista = bsObj.findAll('li')
for name in lista:
  if '<span>' in str(name):
    print (name.find('a').get_text())


