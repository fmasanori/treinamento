import requests
from bs4 import BeautifulSoup as bs

prefix = "https://www.cinemark.com.br"
url_pagina = prefix + "/sao-paulo/filmes/em-cartaz?pagina="
for npagina in (1, 2):    
    p = requests.get(url_pagina+str(npagina))            
    if p.status_code != 200: break
    s = bs(p.content, "html.parser")
    for filme in s.find_all('article',
                            class_='movie'):                     
        a = filme.find('a')
        print (a['title'][6:])
        print (prefix + a['href'])
        
