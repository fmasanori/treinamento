import requests
from bs4 import BeautifulSoup

url = 'https://www.yellowpages.com/search?search_terms=coffe&geo_location_terms=Los+angeles'
r = requests.get(url)

s = BeautifulSoup(r.content, 'html.parser')

data = s.findAll("div",
                 {"class":"info"})

for item in data:
  print (item.get_text())
