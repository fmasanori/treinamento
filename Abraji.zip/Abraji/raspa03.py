from urllib.request import urlopen
from bs4 import BeautifulSoup

html = urlopen("http://www.pythonscraping.com/pages/warandpeace.html")
bsObj = BeautifulSoup(html, "html.parser")
nameList = bsObj.findAll("span", {"class":"green"})
#nameList = bsObj.findAll("span", {"class":"green", "class":"red"})
for name in nameList:
    print(name.get_text())

#findAll(tags, attributes, recursive, text, limit, keywords)
